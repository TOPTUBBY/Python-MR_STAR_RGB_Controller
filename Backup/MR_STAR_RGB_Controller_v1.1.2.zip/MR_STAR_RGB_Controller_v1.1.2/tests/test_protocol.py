import unittest
from protocol import (power_frame, rgb_frame, brightness_frame, hex_to_rgb, rgb_to_hex,
                      matched_brightness, white_frame, mode_frame, speed_frame, direction_frame, EFFECT_PRESETS, brightness_to_raw, applied_brightness, is_primary_rgb)
from ble_manager import is_target

class TestProtocol(unittest.TestCase):
    def test_on_off(self):
        self.assertEqual(power_frame(True), bytes.fromhex('BC 01 01 01 55'))
        self.assertEqual(power_frame(False), bytes.fromhex('BC 01 01 00 55'))
    def test_green(self):
        self.assertEqual(rgb_frame((0, 255, 0)), bytes.fromhex('BC 04 06 00 78 03 E8 00 00 55'))
    def test_red(self):
        self.assertEqual(rgb_frame((255, 0, 0)), bytes.fromhex('BC 04 06 00 00 03 E8 00 00 55'))
    def test_white(self):
        self.assertEqual(rgb_frame((255,255,255)), bytes.fromhex('BC 04 06 00 00 00 00 00 00 55'))
    def test_brightness(self):
        # MR STAR controller uses 16-bit 0..1024, not 0..100.
        # V1.1.0 used to erroneously send 0x0064 at UI 100%.
        self.assertEqual(brightness_frame(100), bytes.fromhex('BC 05 06 04 00 00 00 00 00 55'))
        self.assertEqual(brightness_frame(50), bytes.fromhex('BC 05 06 02 00 00 00 00 00 55'))
        self.assertEqual(brightness_frame(25), bytes.fromhex('BC 05 06 01 00 00 00 00 00 55'))
        self.assertEqual(brightness_frame(0), bytes.fromhex('BC 05 06 00 00 00 00 00 00 55'))
        self.assertEqual(brightness_frame(150), brightness_frame(100))
        self.assertEqual(brightness_to_raw(3), 30)
        self.assertEqual(brightness_to_raw(75), 768)
        self.assertEqual(brightness_to_raw(100), 1024)

    def test_calibration_and_rgb_value(self):
        self.assertEqual(rgb_frame((255, 0, 0)), bytes.fromhex('BC 04 06 00 00 03 E8 00 00 55'))
        self.assertEqual(rgb_frame((255, 0, 0), 10), bytes.fromhex('BC 04 06 00 0A 03 E8 00 00 55'))
        self.assertEqual(matched_brightness((255, 0, 0), 100), 100)
        self.assertEqual(matched_brightness((128, 0, 0), 100), 50)
        self.assertEqual(matched_brightness((255, 0, 0), 60), 60)
        self.assertEqual(matched_brightness((0, 0, 0), 100), 0)

    def test_rgb_primary_firmware_workaround(self):
        # Observed on the user's MODI LIFE: 98% bright, 99–100% dim.
        # The UI must cap only pure R/G/B; never alter other colors.
        for primary in ((255, 0, 0), (0, 255, 0), (0, 0, 255)):
            self.assertTrue(is_primary_rgb(primary))
            self.assertEqual(applied_brightness(primary, 98), 98)
            self.assertEqual(applied_brightness(primary, 99), 98)
            self.assertEqual(applied_brightness(primary, 100), 98)
            self.assertEqual(brightness_frame(applied_brightness(primary, 100)),
                             bytes.fromhex('BC 05 06 03 EB 00 00 00 00 55'))
            self.assertEqual(applied_brightness(primary, 99, False), 99)
            self.assertEqual(applied_brightness(primary, 100, False), 100)
        for mixed in ((255, 255, 0), (0, 255, 255), (255, 0, 255),
                      (255, 255, 255), (255, 128, 0), (0, 0, 0)):
            self.assertFalse(is_primary_rgb(mixed))
            self.assertEqual(applied_brightness(mixed, 100), matched_brightness(mixed, 100))
        self.assertTrue(is_primary_rgb((128, 0, 0)))
        self.assertEqual(applied_brightness((128, 0, 0), 100), 50)

    def test_effect_frames(self):
        self.assertEqual(white_frame(), bytes.fromhex('BC 13 02 00 00 55'))
        self.assertEqual(mode_frame(91), bytes.fromhex('BC 06 02 00 5B 55'))
        self.assertEqual(speed_frame(50), bytes.fromhex('BC 08 01 32 55'))
        self.assertEqual(direction_frame(False), bytes.fromhex('BC 07 01 01 55'))
        with self.assertRaises(ValueError): mode_frame(118)
        self.assertEqual(len(EFFECT_PRESETS), 15)

    def test_hex(self):
        self.assertEqual(hex_to_rgb('#22C55E'), (34, 197, 94))
        self.assertEqual(rgb_to_hex((34,197,94)), '#22C55E')
        with self.assertRaises(ValueError): hex_to_rgb('ZZ0000')
    def test_scan_names(self):
        self.assertTrue(is_target('GATT--DEMO'))
        self.assertTrue(is_target('GATT-DEMO'))
        self.assertFalse(is_target('iPhone'))
if __name__ == '__main__': unittest.main()
